import urllib.request
import urllib.error
import os

def lambda_handler(event, context):
    url = os.environ['CRON_URL']
    secret = os.environ['CRON_SECRET']
    req = urllib.request.Request(url, headers={'Authorization': f'Bearer {secret}'})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read().decode()
            print(f"SUCCESS {resp.status}: {body}")
            return {'statusCode': resp.status, 'body': body}
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"HTTP ERROR {e.code}: {body}")
        return {'statusCode': e.code, 'body': body}
    except Exception as e:
        print(f"ERROR: {e}")
        raise
